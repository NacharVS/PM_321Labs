﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warcraft
{

    internal class Footman : Unit
    {
        public Footman() : base(21, 500, 7, 130, 195, 350)
        {
            health = 500;
            damage = 21;
            Amount = 15;
            skill = 130;
            ultimate = 195;
            mana = 350;
        }
    }


}
