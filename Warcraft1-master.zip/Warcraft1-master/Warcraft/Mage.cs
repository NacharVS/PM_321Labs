﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warcraft
{
    internal class Mage : Unit
    {
        int health = 300;
        int damage = 25;
        int amount = 7;
        int skill = 125;
        int ultimate = 250;
        int mana = 500;


        public Mage() : base(25, 300, 7, 125, 250, 500)
        {
            health = 300;
            damage = 25;
            amount = 7;
            skill = 125;
            ultimate = 250;
            mana = 500;
        }
        public void Molnii(Unit unit)
        {
            if (unit.health - 125 >= 0)
            {
                unit.health -= 125;
            }
            else {
                Console.WriteLine($"{unit.health}EarthSpirit мертв, выиграл Zeus");
            }
        }
        public void Ulta(Unit unit)
        {
            if (unit.health - 250 <= 0 | unit.health - 250 >= 0)
            {
                unit.health -= 250;
            }
            else 
            {
                Console.WriteLine($"EarthSpirit мертв, выиграл Zeus");
            }

        }


    }
}
