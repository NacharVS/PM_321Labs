﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warcraft
{
    internal class Unit
    {
            public int health;
            public int damage;
            public int Amount;
            public int skill;
            public int ultimate;
            public int mana;
        public Unit(int damage, int health, int amount, int skill, int ultimate, int mana)
        {
            this.health = health;
            this.damage = damage;
            this.Amount = amount;
            this.skill = skill;
            this.ultimate = ultimate;
            this.mana = mana;
        }
    }

}
