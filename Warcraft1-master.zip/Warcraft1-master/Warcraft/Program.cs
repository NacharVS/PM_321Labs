﻿using Warcraft;
Footman EarthSpirit = new Footman();
Mage Zeus = new Mage();
Console.WriteLine("EarthSpirit                                         Zeus");
Console.WriteLine();
Console.WriteLine("Здоровье - " + EarthSpirit.health + "                                    " +
    "Здоровье -" + Zeus.health);
Console.WriteLine("Урон - " + EarthSpirit.damage + "                                           Урон - " + Zeus.damage);

Console.WriteLine();



Console.WriteLine("Привет странник, ты будешь играть за Зевса, у него две способности 'q' - это удар молнией, он наносит - 125, а 'w' - это ультимейт, наносящий большое количество урона, то есть - 250 хп");
while (EarthSpirit.health > 0 && Zeus.health > 0) {
    Console.WriteLine("Press 'a' to attack or 'q' to use skill and press 'w' to use ultimate");
    string choice = Console.ReadLine();
    if (choice == "a")
    {
        Random rnd = new Random();
        Zeus.damage = rnd.Next(0, 26);
        EarthSpirit.health -= Zeus.damage;
        Console.WriteLine("Zeus нанес " + Zeus.damage + " урона EarthSpirit, у него осталось " + EarthSpirit.health + "хп");

    }
    else if (choice == "h")
    {
        EarthSpirit.health += EarthSpirit.Amount;
        Console.WriteLine("EarthSpirit вылечил себя благодаря броне на " + EarthSpirit.Amount + " хп, у него сейчас " + EarthSpirit.health + " хп" );

    }
    else if (choice == "q")
    {
        Zeus.Molnii(EarthSpirit);
        Console.WriteLine("у EarthSpirit`a осталось " + EarthSpirit.health + " хп");
    }
    else if (choice =="w")
    {
        Zeus.Ulta(EarthSpirit);
        Console.WriteLine("у EarthSpirita`a осталось " + EarthSpirit.health + "хп");

    }
}

